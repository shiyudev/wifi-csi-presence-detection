"""Check the fitted training artifact without opening any reserved recording."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

import csi_io as io
import models_v8 as model
from dataset_v8 import TRAIN_NAMES, RESERVED_NAMES, load_config
from data_v6 import truth_for


def verify(output):
    root = Path(__file__).resolve().parent
    output = Path(output)
    report = json.loads((output / 'training_report.json').read_text(encoding='utf-8'))
    config = load_config(output / 'manifest_used.json')
    items = {r['file']: r for r in config['records']}
    path = output / 'occupancy_model_v8.joblib'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == report['model_sha256']
    for relative, expected in report['source_hashes'].items():
        assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected, relative
    state = model.load(path)
    assert set(state['training_files']) == TRAIN_NAMES
    assert set(state['reserved_test_files']) == RESERVED_NAMES
    assert len(set(state['training_raw_sha256'])) == 16
    assert len(set(state['training_session_ids'])) == 16
    log = json.loads((output / 'training_access_log.json').read_text(encoding='utf-8'))
    assert len(log) == 16 and {r['file'] for r in log} == TRAIN_NAMES
    with np.load(output / 'training_verification.npz', allow_pickle=False) as saved:
        assert set(saved['recording_file']) == TRAIN_NAMES
        rows = []
        for i, name in enumerate(saved['recording_file']):
            start, end = saved['start_s'][i], saved['end_s'][i]
            item = items[str(name)]
            assert start >= item['signal_start_s']
            assert end - start == 2
            truth = truth_for(start, end, item['intervals'])
            assert truth is not None and int(saved['truth'][i]) == truth
            rows.append(dict(quality='accepted', **{k: saved[k][i]
                        for k in ('dynamic', 'common', 'common_median')}))
        result = model.infer(state['models'], rows)
        for candidate, (prediction, score) in result.items():
            np.testing.assert_array_equal(prediction, saved[candidate + '_prediction'])
            np.testing.assert_array_equal(score, saved[candidate + '_score'])
    check = dict(status='passed', training_files=16, reserved_files=4,
                 eligible_training_windows=len(rows),
                 reloaded_training_predictions_verified=len(rows) * len(model.CANDIDATES),
                 raw_payloads_opened_by_training=16,
                 reserved_payloads_opened_by_training=0,
                 selected_time_boundaries_verified=True,
                 heldout_test_run=False, heldout_accuracy=None)
    io.write_json(output / 'verification.json', check)
    print(json.dumps(check, ensure_ascii=False, indent=2))
    return check


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results', default='results')
    verify(p.parse_args().results)
