"""Focused tests for the requested holdout boundary and label/feature separation."""
import copy
import hashlib
import io as buffer_io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from contextlib import redirect_stdout

import numpy as np

from dataset_v8 import SCENES, TRAIN_NAMES, RESERVED_NAMES, training_blobs, load_config
from data_v6 import recording_rows, truth_for
from features_v7 import add_features
import models_v8 as model


class Tests(unittest.TestCase):
    def test_reserved_payloads_are_never_opened(self):
        with tempfile.TemporaryDirectory() as temp:
            archives = []
            for k, scenes in enumerate((SCENES[:2], SCENES[2:])):
                path = Path(temp) / f'input{k}.zip'; archives.append(path)
                with zipfile.ZipFile(path, 'w') as z:
                    for scene in scenes:
                        for n in range(1, 6):
                            z.writestr(f'folder/{scene}{n}.jsonl', f'{scene}{n}'.encode())
            original = zipfile.ZipFile.open
            def guarded(instance, member, *args, **kwargs):
                name = member.filename if isinstance(member, zipfile.ZipInfo) else member
                if Path(name).name in RESERVED_NAMES:
                    raise AssertionError('A reserved recording was opened')
                return original(instance, member, *args, **kwargs)
            log = []
            with patch.object(zipfile.ZipFile, 'open', guarded):
                read = list(training_blobs(archives, log))
            self.assertEqual({name for name, _ in read}, TRAIN_NAMES)
            self.assertEqual(len(read), 16)
            self.assertEqual({r['file'] for r in log}, TRAIN_NAMES)

    def test_manifest_cannot_admit_number_five(self):
        source = Path(__file__).parent / 'labels_train.json'
        config = json.loads(source.read_text(encoding='utf-8'))
        config['records'][0]['file'] = '无人5.jsonl'
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'labels.json'; path.write_text(json.dumps(config))
            with self.assertRaises(ValueError): load_config(path)

    def test_outside_scene_remains_unoccupied(self):
        config = load_config(Path(__file__).parent / 'labels_train.json')
        for item in config['records']:
            if item['file'].startswith(('无人', '门外走动')):
                self.assertEqual([i['label'] for i in item['intervals']], [1, 0, 1])
                self.assertEqual(item['intervals'][0]['activity'], 'departure')
                self.assertEqual(item['intervals'][2]['activity'], 'arrival')

    def test_cross_boundary_windows_are_excluded(self):
        spans = [dict(start_s=10.5, end_s=20.5, label=0)]
        self.assertIsNone(truth_for(9, 11, spans))
        self.assertIsNone(truth_for(19, 21, spans))
        self.assertEqual(truth_for(11, 13, spans), 0)

    def test_selected_features_ignore_discarded_edges(self):
        rng = np.random.default_rng(9)
        t = np.arange(0, 30, .01); seq = np.arange(len(t))
        a = 20 + rng.normal(0, .5, (len(t), 64))
        item = dict(file='synthetic', group_id='g', fold=0, include=True,
                    review_status='synthetic', anchor_s=1., signal_start_s=11., end_trim_s=1.,
                    intervals=[dict(start_s=11., end_s=21., label=0, evidence='synthetic')])
        def selected(amplitude, cfg):
            rows = [r for r in recording_rows(t, seq, amplitude, cfg) if r['scoring_eligible']]
            return add_features(rows, t, amplitude)
        before = selected(a, item)
        changed = a.copy(); changed[(t < 11) | (t >= 21)] = 1e9
        after = selected(changed, item)
        for x, y in zip(before, after):
            for kind in ('dynamic', 'common', 'common_median'):
                np.testing.assert_array_equal(x[kind], y[kind])
        other = copy.deepcopy(item); other['file'] = 'renamed'
        other['intervals'][0]['label'] = 1
        for x, y in zip(before, selected(a, other)):
            for kind in ('dynamic', 'common', 'common_median'):
                np.testing.assert_array_equal(x[kind], y[kind])

    def test_parameters_and_thresholds_are_fixed(self):
        forest = model.estimator(42)
        self.assertEqual(forest.n_estimators, 200)
        self.assertEqual(forest.max_depth, 5)
        self.assertEqual(forest.min_samples_leaf, 3)
        self.assertEqual(forest.random_state, 42)
        self.assertEqual(model.CANDIDATES['v6_rf']['threshold'], .5)
        self.assertEqual(model.CANDIDATES['common_rf']['threshold'], .5)
        self.assertEqual(model.CANDIDATES['rf_threshold_060']['threshold'], .6)

    def test_training_and_verification_artifacts_round_trip(self):
        import train
        import verify
        root = Path(__file__).parent
        manifest = root / 'labels_train.json'
        config = load_config(manifest)
        rows, raw, log = [], {}, []
        for i, item in enumerate(config['records']):
            name = item['file']
            for interval in item['intervals']:
                target = interval['label']
                start = 1 + 2 * int(np.ceil((interval['start_s'] - 1) / 2))
                rows.append(dict(file=name, truth=target, quality='accepted', scoring_eligible=True,
                                 start_s=float(start), end_s=float(start+2), activity=interval['activity'],
                                 dynamic=np.full(256, target+.1*i),
                                 common=np.full(12, target+.1*i),
                                 common_median=np.full(12, target+.1*i)))
            raw[name] = dict(audit=dict(raw_sha256=f'synthetic_hash_{i}', session_id=f'synthetic_{i}'))
            log.append(dict(file=name, role='training'))
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / 'results'; plan = Path(d) / 'plan.json'
            plan.write_text(json.dumps(dict(seed=42, default_candidate='v6_rf',
                source_hashes={'labels_train.json':hashlib.sha256(manifest.read_bytes()).hexdigest()})))
            with patch.object(train, 'read_training', return_value=(config, raw, rows, log)), redirect_stdout(buffer_io.StringIO()):
                train.run([], manifest, out, plan)
                checked = verify.verify(out)
            self.assertEqual(checked['reloaded_training_predictions_verified'], 128)
            self.assertFalse(checked['heldout_test_run'])


if __name__ == '__main__': unittest.main(verbosity=2)
