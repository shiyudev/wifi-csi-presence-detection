"""Fit the fixed V7 methods on today's 1-4 recordings. Leave every 5 untouched."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

import csi_io as io
import models_v8 as model
from dataset_v8 import TRAIN_NAMES, RESERVED_NAMES, read_training


def run(archives, manifest, output, plan_path):
    root = Path(__file__).resolve().parent
    plan = json.loads(Path(plan_path).read_text(encoding='utf-8'))
    for relative, expected in plan['source_hashes'].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen training source changed: ' + relative)
    if hashlib.sha256(Path(manifest).read_bytes()).hexdigest() != plan['source_hashes']['labels_train.json']:
        raise ValueError('Use the frozen training manifest')
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('Choose a new, empty output directory')
    output.mkdir(parents=True, exist_ok=True)
    config, raw, all_rows, access_log = read_training(archives, manifest)
    rows = [r for r in all_rows if r['scoring_eligible']]
    assert {r['file'] for r in rows} == TRAIN_NAMES
    fitted = model.fit_models(rows, plan['seed'])
    state = model.state_for(fitted, rows, raw, plan['seed'],
                            'nov03_train_numbers_1_2_3_4', plan['default_candidate'])
    state.update(training_scope='today_only_numbers_1_2_3_4',
                 reserved_test_files=sorted(RESERVED_NAMES),
                 test_evaluated=False, old_recordings_included=False,
                 training_plan_sha256=hashlib.sha256(Path(plan_path).read_bytes()).hexdigest(),
                 frozen_at_utc=datetime.now(timezone.utc).isoformat())
    model_path = output / 'occupancy_model_v8.joblib'
    model.save_verified(state, model_path, rows)
    restored = model.load(model_path)
    predictions = model.infer(restored['models'], rows)
    arrays = {kind: np.array([r[kind] for r in rows])
              for kind in ('dynamic', 'common', 'common_median')}
    arrays.update(truth=np.array([r['truth'] for r in rows], int),
                  recording_file=np.array([r['file'] for r in rows]),
                  start_s=np.array([r['start_s'] for r in rows]),
                  end_s=np.array([r['end_s'] for r in rows]))
    for name, (pred, score) in predictions.items():
        arrays[name + '_prediction'] = pred
        arrays[name + '_score'] = score
    np.savez_compressed(output / 'training_verification.npz', **arrays)
    io.write_json(output / 'manifest_used.json', config)
    io.write_json(output / 'training_access_log.json', access_log)
    io.write_csv(output / 'recording_audit.csv', [v['audit'] for v in raw.values()])
    excluded_keys = {'dynamic', 'multiscale', 'common', 'common_median'}
    io.write_csv(output / 'window_audit.csv', [
        {k: v for k, v in r.items() if k not in excluded_keys} for r in all_rows])
    by_scene = {}
    for scene in ('无人', '门外走动', '玩电脑', '走动'):
        chosen = [r for r in rows if r['file'] in {f'{scene}{n}.jsonl' for n in (1,2,3,4)}]
        by_scene[scene] = dict(files=4, windows=len(chosen), seconds=2 * len(chosen),
                               occupied_windows=sum(r['truth'] == 1 for r in chosen),
                               unoccupied_windows=sum(r['truth'] == 0 for r in chosen))
    by_activity = {activity:sum(r['activity'] == activity for r in rows)
                   for activity in sorted({r['activity'] for r in rows})}
    report = dict(version=model.VERSION, status='trained_and_frozen',
                  training_files=16, reserved_test_files=sorted(RESERVED_NAMES),
                  training_windows=len(rows), by_scene=by_scene, by_activity=by_activity,
                  default_candidate=state['default_candidate'],
                  available_candidates=list(model.CANDIDATES),
                  trained_forests=len(fitted), seed=plan['seed'],
                  reserved_payloads_read=0, heldout_predictions_computed=0,
                  heldout_accuracy=None, hyperparameter_search=False,
                  validation_or_test_performed=False,
                  old_recordings_included=False, pictures_used_as_features=False,
                  model_sha256=hashlib.sha256(model_path.read_bytes()).hexdigest(),
                  source_hashes=plan['source_hashes'],
                  notes=['User confirmed blue-line exterior segments are departure and arrival, labeled occupied.',
                         'User confirmed videos and CSI start together; video ends earlier. CSI tails use filename labels without video corroboration.',
                         'Feature processing and estimator parameters are unchanged from V7.',
                         'No accuracy or improvement is claimed before the reserved test.'])
    io.write_json(output / 'training_report.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--zip', action='append', required=True, dest='archives')
    p.add_argument('--manifest', default='labels_train.json')
    p.add_argument('--out', default='results')
    p.add_argument('--plan', default='training_plan.json')
    args = p.parse_args()
    run(args.archives, args.manifest, args.out, args.plan)
